package com.sqli.relevemeteo

const val DEFAULT_DATE_FORMAT = "dd/MM/yyyy"